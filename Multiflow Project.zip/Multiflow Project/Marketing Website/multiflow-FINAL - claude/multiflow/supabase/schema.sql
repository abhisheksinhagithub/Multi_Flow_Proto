-- ============================================================
-- MULTIFLOW — Supabase schema
-- Run this once in your Supabase project's SQL Editor
-- (Project → SQL Editor → New query → paste → Run)
-- ============================================================

-- ---------- 1. PROFILES ----------
-- Extends Supabase's built-in auth.users with app-specific fields.
-- One row is created automatically for every new signup via a trigger.
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  account_name text not null,
  phone text,
  role text not null default 'customer' check (role in ('customer','admin')),
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;

create policy "Users can read their own profile"
  on public.profiles for select
  using (auth.uid() = id);

create policy "Users can update their own profile"
  on public.profiles for update
  using (auth.uid() = id);

create policy "Admins can read all profiles"
  on public.profiles for select
  using (exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin'));


-- ---------- 2. BUSINESSES ----------
-- One row per signed-up business, holds everything from the signup wizard.
create table if not exists public.businesses (
  id uuid primary key default gen_random_uuid(),
  profile_id uuid not null references public.profiles(id) on delete cascade,

  business_name text not null,
  business_type text,
  category text,
  gstin text,
  pan text,
  website text,
  address text,
  city text,
  state text,
  pincode text,

  wa_number text,
  display_name text,
  fb_bm_id text,
  volume text,
  use_case text,
  channels text[] default array['whatsapp'],

  account_type text not null default 'individual' check (account_type in ('individual','reseller')),

  plan text not null default 'starter' check (plan in ('starter','growth','enterprise')),
  status text not null default 'pending_verification'
    check (status in ('pending_verification','approved','rejected')),

  created_at timestamptz not null default now(),
  reviewed_at timestamptz,
  reviewed_by uuid references public.profiles(id)
);

alter table public.businesses enable row level security;

create policy "Business owners can read their own business"
  on public.businesses for select
  using (profile_id = auth.uid());

create policy "Business owners can insert their own business"
  on public.businesses for insert
  with check (profile_id = auth.uid());

create policy "Business owners can update their own business"
  on public.businesses for update
  using (profile_id = auth.uid());

create policy "Admins can read all businesses"
  on public.businesses for select
  using (exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin'));

create policy "Admins can update all businesses"
  on public.businesses for update
  using (exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin'));


-- ---------- 3. AUTO-CREATE PROFILE ON SIGNUP ----------
-- Whenever someone signs up via supabase.auth.signUp(), this trigger
-- creates their matching row in public.profiles automatically.
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
begin
  insert into public.profiles (id, account_name, phone, role)
  values (
    new.id,
    coalesce(new.raw_user_meta_data->>'account_name', new.email),
    new.raw_user_meta_data->>'phone',
    'customer'
  );
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();


-- ---------- 4. RESELLER CLIENTS ----------
-- Only relevant for businesses with account_type = 'reseller'.
-- Lets a reseller manage their own sub-accounts/clients under their brand.
create table if not exists public.reseller_clients (
  id uuid primary key default gen_random_uuid(),
  reseller_business_id uuid not null references public.businesses(id) on delete cascade,
  client_name text not null,
  client_email text,
  client_phone text,
  plan text default 'starter',
  status text not null default 'active' check (status in ('active','suspended')),
  created_at timestamptz not null default now()
);

alter table public.reseller_clients enable row level security;

create policy "Resellers can manage their own clients"
  on public.reseller_clients for all
  using (reseller_business_id in (select id from public.businesses where profile_id = auth.uid()))
  with check (reseller_business_id in (select id from public.businesses where profile_id = auth.uid()));

create policy "Admins can read all reseller clients"
  on public.reseller_clients for select
  using (exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin'));


-- ---------- 5. MAKE SOMEONE AN ADMIN ----------
-- Run this manually after your first admin signs up normally through
-- the website (replace the email):
--
-- update public.profiles set role = 'admin'
-- where id = (select id from auth.users where email = 'admin@multiflow.co.in');


-- ---------- 6. INDEXES ----------
create index if not exists idx_businesses_status on public.businesses(status);
create index if not exists idx_businesses_profile on public.businesses(profile_id);
create index if not exists idx_reseller_clients_business on public.reseller_clients(reseller_business_id);

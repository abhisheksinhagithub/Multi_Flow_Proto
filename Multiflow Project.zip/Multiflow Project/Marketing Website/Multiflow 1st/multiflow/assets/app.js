/* ============================================================
   MULTIFLOW — demo data & auth layer
   NOTE: This simulates a backend using localStorage so the full
   signup -> verification -> login -> dashboard/admin flow is
   clickable end-to-end. Replace with real API calls + a database
   when you build the backend.
   ============================================================ */

const CHANNELS = [
  { key: "whatsapp", label: "WhatsApp", color: "#17B8A6" },
  { key: "sms", label: "SMS", color: "#6C5CE7" },
  { key: "rcs", label: "RCS", color: "#8F87F0" },
  { key: "voice", label: "Voice", color: "#FF6B4A" },
  { key: "email", label: "Email", color: "#4FD1C5" },
];

const PLANS = [
  { id: "starter", name: "Starter", price: "₹2,999/mo", desc: "Up to 10,000 msgs · WhatsApp + SMS" },
  { id: "growth", name: "Growth", price: "₹8,999/mo", desc: "Up to 75,000 msgs · All 5 channels" },
  { id: "enterprise", name: "Enterprise", price: "Custom", desc: "Unlimited · Dedicated support" },
];

function loadAccounts() {
  return JSON.parse(localStorage.getItem("mf_accounts") || "[]");
}
function saveAccounts(list) {
  localStorage.setItem("mf_accounts", JSON.stringify(list));
}
function getSession() {
  return JSON.parse(localStorage.getItem("mf_session") || "null");
}
function setSession(s) {
  localStorage.setItem("mf_session", JSON.stringify(s));
}
function clearSession() {
  localStorage.removeItem("mf_session");
}

function seedIfEmpty() {
  const accounts = loadAccounts();
  if (accounts.length) return;
  const seed = [
    {
      id: "admin-1", role: "admin",
      accountName: "Multiflow Admin", email: "admin@multiflow.co.in", password: "admin123",
      businessName: "Multiflow HQ", status: "approved", createdAt: "2026-06-01",
    },
    {
      id: "cust-1", role: "customer",
      accountName: "Ritu Sharma", email: "demo@business.com", password: "demo1234",
      businessName: "Sharma Fashion Retail", businessType: "Pvt Ltd", category: "E-commerce",
      gstin: "27ABCDE1234F1Z5", pan: "ABCDE1234F", website: "https://sharmafashion.in",
      address: "MG Road", city: "Bengaluru", state: "Karnataka", pincode: "560001",
      waNumber: "+91 98200 11223", displayName: "Sharma Fashion", fbBmId: "1029384756",
      volume: "10,000 - 50,000 / month", useCase: "Marketing & Utility",
      plan: "growth", status: "approved", createdAt: "2026-07-14",
    },
    {
      id: "cust-2", role: "customer",
      accountName: "Arjun Mehta", email: "arjun@newbiz.com", password: "demo1234",
      businessName: "Newbiz Coaching Institute", businessType: "Proprietorship", category: "Education",
      gstin: "", pan: "PQRSX5678K", website: "",
      address: "Sector 21", city: "Noida", state: "Uttar Pradesh", pincode: "201301",
      waNumber: "+91 90040 55321", displayName: "Newbiz Coaching", fbBmId: "",
      volume: "Under 10,000 / month", useCase: "Authentication",
      plan: "starter", status: "pending_verification", createdAt: "2026-08-10",
    },
  ];
  saveAccounts(seed);
}

function channelMeta(key) {
  return CHANNELS.find((c) => c.key === key) || CHANNELS[0];
}

function statusPillClass(status) {
  const map = {
    approved: "good", Approved: "good", Completed: "good", Operational: "good", Paid: "good",
    pending_verification: "warn", Pending: "warn", Scheduled: "warn", Degraded: "warn",
    rejected: "bad", Rejected: "bad",
    Running: "brand", Draft: "neutral",
  };
  return map[status] || "neutral";
}
function statusLabel(status) {
  const map = { approved: "Approved", pending_verification: "Pending verification", rejected: "Rejected" };
  return map[status] || status;
}

// Guard helpers for protected pages
function requireRole(role) {
  const s = getSession();
  if (!s || s.role !== role) {
    window.location.href = "login.html";
    return null;
  }
  return s;
}

document.addEventListener("DOMContentLoaded", seedIfEmpty);

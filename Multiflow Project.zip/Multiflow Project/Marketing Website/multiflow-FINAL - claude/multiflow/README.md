# Multiflow — complete website (demo mode)

A full omnichannel-messaging SaaS website: public marketing site, working
signup/login with an Individual vs Reseller choice, a customer dashboard
(Inbox, Contacts, Templates, Campaign builder + Reports, Analytics, Billing,
Settings, and a Clients tab for resellers), and an admin console for
approving businesses.

**This build works immediately with zero setup** — no database, no API
keys. It uses your browser's `localStorage` to simulate accounts, sessions,
and data, so every click, form, and workflow is genuinely functional out of
the box. When you're ready to go live, swap in the included Supabase
backend (see "Going live" below).

## Open it

Just open `index.html` in a browser — works fully offline, no server needed.

## Try the full flow

1. **Sign up** (`signup.html`) — choose "My own business" or "Reseller / Agency" at the top, fill in the wizard, submit → account is created as "pending verification."
2. **Log in** (`login.html`) — use the account you just created, or the demo shortcuts:
   - `demo@business.com` / `demo1234` — individual business (approved)
   - `demo@agency.com` / `demo1234` — reseller (approved, has 3 sample clients already)
   - `admin@multiflow.co.in` / `admin123` — admin console
3. **As admin** → Verifications tab → approve/reject any pending signup. Log back in as that business and the pending banner is gone.
4. **As the reseller demo account** → a **Clients** tab appears automatically in the sidebar (individual accounts don't see this) → add/suspend sub-accounts.
5. **Any business dashboard** → Inbox (live chat), Campaigns (5-step wizard → funnel report), Analytics, Settings.

## Structure

```
index.html, products.html, solutions.html,      Public marketing site
company.html, blog.html, contact.html, legal.html

signup.html, login.html                          Auth (demo — localStorage)
dashboard.html                                    Customer app (individual or reseller)
admin.html                                        Admin console

assets/style.css                                  Marketing site design system
assets/app.css                                     Auth/dashboard/admin app shell
assets/script.js, assets/partials.js                Marketing site behavior + shared nav/footer
assets/app.js                                       Demo data + auth layer (localStorage)
assets/supabase-client.js                           Real backend layer — see "Going live"

supabase/schema.sql                                Database schema for the real backend
robots.txt, sitemap.xml                             SEO
FLOW.md                                              Full click-through flow, page by page
```

## Going live (swap demo for a real backend)

`assets/supabase-client.js` and `supabase/schema.sql` are already built and
include the same Individual/Reseller/`reseller_clients` structure as this
demo. To connect a real database:

1. Create a free project at supabase.com, run `supabase/schema.sql` in its SQL Editor.
2. Put your Project URL + anon key into `assets/supabase-client.js`.
3. In `signup.html`, `login.html`, `dashboard.html`, and `admin.html`, swap the `<script src="assets/app.js">` tag for `<script src="assets/supabase-client.js">` (plus the Supabase CDN script — see the comment at the top of `supabase-client.js`), and change the auth calls to their async equivalents (`requireRole` → `requireProfileRole`, `loadAccounts()` → `listAllBusinesses()`, etc. — matching function names are documented in `supabase-client.js`).
4. Serve the folder over `http://` (not `file://`) since Supabase auth needs a real origin — `npx serve .` works.

## What's real vs. mock in this demo build

**Fully working, persists in your browser:**
- Signup, login, session, admin approve/reject, reseller client add/suspend — all via `localStorage`, survives page reloads (not across browsers/devices)

**UI-complete but sample data:**
- Inbox conversations, Contacts, Templates, Campaigns, Analytics numbers — fully interactive, not connected to a real message history
- No channel is actually connected — no real WhatsApp/SMS/RCS/Voice/Email is sent
- Marketing site's contact form shows a success message but doesn't send anywhere

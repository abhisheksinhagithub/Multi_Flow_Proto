MULTIFLOW MARKETING WEBSITE V4

Public marketing package only. Includes Home, Products, Solutions, Pricing, Reseller/Agency, Resources, Company, Contact, Legal and Buy Online.

Hero: each of the five channel labels/status pills is attached to the END of its own branch (not stacked separately below).

Login/Signup links intentionally point to your existing authentication pages. Dashboard/admin/super-admin are not included.

Payment: front-end checkout flow only. Connect real gateway, server-side verification, webhook, invoice and wallet/credit activation in the application/backend phase.

Before production: replace placeholder contact details, legal text, LIVE/COMING SOON statuses, and any other business-specific copy.

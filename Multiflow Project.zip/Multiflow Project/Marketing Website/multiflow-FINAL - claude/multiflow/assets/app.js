/* ============================================================
   MULTIFLOW — demo data & auth layer (localStorage)
   Fully self-contained so every page works immediately with no
   setup. Swap this file for assets/supabase-client.js (see the
   /supabase folder) when you're ready to connect a real database.
   ============================================================ */

const CHANNELS = [
  { key: "whatsapp", label: "WhatsApp", color: "#17B8A6" },
  { key: "sms", label: "SMS", color: "#6C5CE7" },
  { key: "rcs", label: "RCS", color: "#8F87F0" },
  { key: "voice", label: "Voice", color: "#FF6B4A" },
  { key: "email", label: "Email", color: "#4FD1C5" },
];

const PLANS = [
  { id: "starter", name: "Starter", price: "₹2,999/mo", desc: "Up to 10,000 msgs · WhatsApp + SMS" },
  { id: "growth", name: "Growth", price: "₹8,999/mo", desc: "Up to 75,000 msgs · All 5 channels" },
  { id: "enterprise", name: "Enterprise", price: "Custom", desc: "Unlimited · Dedicated support" },
];

// ---------- Accounts (businesses + admin) ----------
function loadAccounts() { return JSON.parse(localStorage.getItem("mf_accounts") || "[]"); }
function saveAccounts(list) { localStorage.setItem("mf_accounts", JSON.stringify(list)); }

// ---------- Session ----------
function getSession() { return JSON.parse(localStorage.getItem("mf_session") || "null"); }
function setSession(s) { localStorage.setItem("mf_session", JSON.stringify(s)); }
function clearSession() { localStorage.removeItem("mf_session"); }

// ---------- Reseller sub-accounts ----------
function loadClients() { return JSON.parse(localStorage.getItem("mf_clients") || "[]"); }
function saveClients(list) { localStorage.setItem("mf_clients", JSON.stringify(list)); }
function listMyClients(businessId) {
  return loadClients().filter(c => c.resellerBusinessId === businessId)
    .sort((a, b) => (a.createdAt < b.createdAt ? 1 : -1));
}
function addClient(businessId, client) {
  const clients = loadClients();
  clients.push({
    id: "client-" + Date.now(),
    resellerBusinessId: businessId,
    clientName: client.name,
    clientEmail: client.email,
    clientPhone: client.phone,
    plan: client.plan || "starter",
    status: "active",
    createdAt: new Date().toISOString(),
  });
  saveClients(clients);
}
function setClientStatus(clientId, status) {
  const clients = loadClients();
  const idx = clients.findIndex(c => c.id === clientId);
  if (idx > -1) { clients[idx].status = status; saveClients(clients); }
}

// ---------- Seed demo data on first load ----------
function seedIfEmpty() {
  const accounts = loadAccounts();
  if (accounts.length) return;

  const seed = [
    {
      id: "admin-1", role: "admin",
      accountName: "Multiflow Admin", email: "admin@multiflow.co.in", password: "admin123",
      businessName: "Multiflow HQ", status: "approved", createdAt: "2026-06-01",
    },
    {
      id: "cust-1", role: "customer", accountType: "individual",
      accountName: "Ritu Sharma", email: "demo@business.com", password: "demo1234",
      businessName: "Sharma Fashion Retail", businessType: "Pvt Ltd", category: "E-commerce",
      gstin: "27ABCDE1234F1Z5", pan: "ABCDE1234F", website: "https://sharmafashion.in",
      address: "MG Road", city: "Bengaluru", state: "Karnataka", pincode: "560001",
      waNumber: "+91 98200 11223", displayName: "Sharma Fashion", fbBmId: "1029384756",
      volume: "10,000 - 50,000 / month", useCase: "Marketing & Utility", channels: ["whatsapp","sms"],
      plan: "growth", status: "approved", createdAt: "2026-07-14",
    },
    {
      id: "cust-2", role: "customer", accountType: "individual",
      accountName: "Arjun Mehta", email: "arjun@newbiz.com", password: "demo1234",
      businessName: "Newbiz Coaching Institute", businessType: "Proprietorship", category: "Education",
      gstin: "", pan: "PQRSX5678K", website: "",
      address: "Sector 21", city: "Noida", state: "Uttar Pradesh", pincode: "201301",
      waNumber: "+91 90040 55321", displayName: "Newbiz Coaching", fbBmId: "",
      volume: "Under 10,000 / month", useCase: "Authentication", channels: ["whatsapp"],
      plan: "starter", status: "pending_verification", createdAt: "2026-08-10",
    },
    {
      id: "cust-3", role: "customer", accountType: "reseller",
      accountName: "Devika Iyer", email: "demo@agency.com", password: "demo1234",
      businessName: "Pixel Reach Agency", businessType: "LLP", category: "Agency",
      gstin: "29FGHIJ5678K1Z2", pan: "FGHIJ5678K", website: "https://pixelreach.in",
      address: "Indiranagar", city: "Bengaluru", state: "Karnataka", pincode: "560038",
      waNumber: "+91 98450 22110", displayName: "Pixel Reach", fbBmId: "8877665544",
      volume: "2,00,000+ / month", useCase: "Marketing & Utility", channels: ["whatsapp","sms","rcs","voice","email"],
      plan: "enterprise", status: "approved", createdAt: "2026-05-02",
    },
  ];
  saveAccounts(seed);

  saveClients([
    { id:"client-1", resellerBusinessId:"cust-3", clientName:"Blue Orchid Interiors", clientEmail:"hello@blueorchid.in", clientPhone:"+91 98765 43210", plan:"growth", status:"active", createdAt:"2026-07-01" },
    { id:"client-2", resellerBusinessId:"cust-3", clientName:"QuickBite Restaurants", clientEmail:"ops@quickbite.in", clientPhone:"+91 91234 56780", plan:"starter", status:"active", createdAt:"2026-07-20" },
    { id:"client-3", resellerBusinessId:"cust-3", clientName:"Vertex Realty Group", clientEmail:"info@vertexrealty.in", clientPhone:"+91 99887 76655", plan:"enterprise", status:"suspended", createdAt:"2026-06-15" },
  ]);
}

// ---------- Shared UI utilities ----------
function channelMeta(key) { return CHANNELS.find((c) => c.key === key) || CHANNELS[0]; }

function statusPillClass(status) {
  const map = {
    approved: "good", Approved: "good", Completed: "good", Operational: "good", Paid: "good", active: "good",
    pending_verification: "warn", Pending: "warn", Scheduled: "warn", Degraded: "warn",
    rejected: "bad", Rejected: "bad", suspended: "bad",
    Running: "brand", Draft: "neutral",
  };
  return map[status] || "neutral";
}
function statusLabel(status) {
  const map = { approved: "Approved", pending_verification: "Pending verification", rejected: "Rejected" };
  return map[status] || status;
}

// ---------- Auth guard ----------
function requireRole(role) {
  const s = getSession();
  if (!s || s.role !== role) { window.location.href = "login.html"; return null; }
  return s;
}

document.addEventListener("DOMContentLoaded", seedIfEmpty);

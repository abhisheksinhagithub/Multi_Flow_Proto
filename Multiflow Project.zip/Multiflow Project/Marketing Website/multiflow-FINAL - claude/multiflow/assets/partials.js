document.write(`
<nav class="nav">
  <div class="wrap">
    <a href="index.html" class="brand">
      <img src="assets/multiflow-icon-transparent.png" alt="Multiflow" style="height:28px; width:auto;">
      Multiflow
    </a>
    <ul class="nav-links">
      <li><a href="index.html">Home</a></li>
      <li><a href="products.html">Products</a></li>
      <li><a href="solutions.html">Solutions</a></li>
      <li><a href="company.html">Company</a></li>
      <li><a href="blog.html">Resources</a></li>
      <li><a href="contact.html">Contact</a></li>
    </ul>
    <div class="nav-cta">
      <a href="login.html" class="btn btn--ghost btn--sm">Login</a>
      <a href="signup.html" class="btn btn--primary btn--sm">Get Started</a>
      <button class="nav-toggle" aria-label="Menu"><span></span><span></span><span></span></button>
    </div>
  </div>
</nav>
`);

function writeMultiflowFooter() {
  document.write(`
<footer class="footer">
  <div class="wrap">
    <div class="footer-brand">
      <a href="index.html" class="brand" style="color:var(--text-on-ink);">
        <img src="assets/multiflow-icon-transparent.png" alt="Multiflow" style="height:28px; width:auto;">
        Multiflow
      </a>
      <p>One platform for WhatsApp, SMS, RCS, Voice and Email — built for businesses across India.</p>
    </div>
    <div><h4>Products</h4><ul>
      <li><a href="products.html#whatsapp">WhatsApp API</a></li>
      <li><a href="products.html#sms">Bulk SMS</a></li>
      <li><a href="products.html#rcs">RCS Messaging</a></li>
      <li><a href="products.html#voice">Voice</a></li>
      <li><a href="products.html#email">Email Marketing</a></li>
    </ul></div>
    <div><h4>Company</h4><ul>
      <li><a href="company.html">About Multiflow</a></li>
      <li><a href="company.html#why">Why us</a></li>
      <li><a href="blog.html">Blog</a></li>
      <li><a href="contact.html">Contact</a></li>
    </ul></div>
    <div><h4>Legal</h4><ul>
      <li><a href="legal.html#privacy">Privacy Policy</a></li>
      <li><a href="legal.html#terms">Terms &amp; Conditions</a></li>
      <li><a href="legal.html#refund">Refund Policy</a></li>
    </ul></div>
    <div><h4>Contact</h4><ul>
      <li><a href="mailto:info@multiflow.co.in">info@multiflow.co.in</a></li>
      <li><a href="tel:+919999999999">+91 99999 99999</a></li>
      <li><a href="https://wa.me/919999999999">WhatsApp us</a></li>
    </ul></div>
  </div>
  <div class="footer-bottom">
    <span>© <span class="year"></span> Multiflow. All rights reserved.</span>
    <span>multiflow.co.in</span>
  </div>
</footer>

<a href="https://wa.me/919999999999?text=Hi%20Multiflow%2C%20I%27d%20like%20to%20know%20more" class="wa-float" aria-label="Chat on WhatsApp">
  <svg width="28" height="28" viewBox="0 0 24 24" fill="#fff"><path d="M12 2C6.48 2 2 6.48 2 12c0 1.85.5 3.58 1.36 5.07L2 22l5.06-1.33A9.94 9.94 0 0 0 12 22c5.52 0 10-4.48 10-10S17.52 2 12 2zm0 18c-1.6 0-3.1-.44-4.38-1.2l-.31-.19-3.13.82.84-3.04-.2-.32A7.94 7.94 0 0 1 4 12c0-4.41 3.59-8 8-8s8 3.59 8 8-3.59 8-8 8zm4.4-5.6c-.24-.12-1.42-.7-1.64-.78-.22-.08-.38-.12-.54.12-.16.24-.62.78-.76.94-.14.16-.28.18-.52.06-.24-.12-1.02-.38-1.94-1.2-.72-.64-1.2-1.43-1.34-1.67-.14-.24-.02-.37.1-.49.11-.11.24-.28.36-.42.12-.14.16-.24.24-.4.08-.16.04-.3-.02-.42-.06-.12-.54-1.3-.74-1.78-.2-.47-.4-.4-.54-.41h-.46c-.16 0-.42.06-.64.3-.22.24-.84.82-.84 2s.86 2.32.98 2.48c.12.16 1.7 2.6 4.12 3.64.58.25 1.03.4 1.38.51.58.18 1.11.16 1.53.1.47-.07 1.42-.58 1.62-1.14.2-.56.2-1.04.14-1.14-.06-.1-.22-.16-.46-.28z"/></svg>
</a>
<script src="assets/script.js"><\/script>
`);
}

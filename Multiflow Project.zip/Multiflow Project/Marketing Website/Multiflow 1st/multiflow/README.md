# Multiflow — Complete Website (v1)

A full omnichannel messaging SaaS website for **multiflow.co.in** — marketing site, business signup with verification, customer dashboard, and reseller admin console — all in one static bundle.

## How to preview

Just unzip and open `index.html` in a browser — the whole thing works offline, no server required (uses `localStorage` to simulate accounts/sessions).

## Site map

### Marketing site (public)
| Page | Purpose |
|---|---|
| `index.html` | Home — hero, features, why us, industries, testimonials, FAQ |
| `products.html` | WhatsApp API, Bulk WhatsApp, SMS, RCS, Voice, Email, AI Chatbot, Automation, API/Webhooks |
| `solutions.html` | Education, Real Estate, E-commerce, Healthcare, Finance, Restaurants, Agencies, SMB |
| `company.html` | About, mission, vision, why us |
| `blog.html` | Resources / guides listing |
| `contact.html` | Lead form, business enquiry form, newsletter, direct contact |
| `legal.html` | Privacy Policy, Terms & Conditions, Refund Policy (placeholder — needs legal review) |

### App (behind login)
| Page | Purpose |
|---|---|
| `signup.html` | 4-step business onboarding: account → business/KYC details → WhatsApp & channel setup → plan + review |
| `login.html` | Email/password login + one-click demo logins |
| `dashboard.html` | Customer app: Overview, **Inbox** (live chat), Contacts, Templates, **Campaigns** (5-step builder), **Reports** (delivery funnel + trend), Analytics, Billing, Settings |
| `admin.html` | Reseller console: Overview, **Verification queue** (approve/reject signups), All customers, Revenue/MRR, Support tickets, Platform settings (wholesale rates, upstream API keys) |

## Demo logins
- **Business account:** `demo@business.com` / `demo1234`
- **Admin account:** `admin@multiflow.co.in` / `admin123`
- Or sign up fresh via `signup.html` → approve it yourself from the admin Verifications tab.

## What's real vs. simulated

**Real & working right now:**
- Every page, nav, animation, form validation, and interaction
- The full signup → pending verification → admin approval → live dashboard flow (via `localStorage`)
- Campaign wizard, chat inbox (in-memory), reports/funnels — all genuinely interactive

**Simulated (needs backend to go live):**
- `localStorage` stands in for a real database — data lives only in your browser, not shared across devices/users
- No real WhatsApp/SMS/RCS/Voice/Email sending — channel integrations are the next build phase
- Contact form on `contact.html` shows a success message but isn't wired to an email/CRM endpoint

## Before going live
1. Replace placeholder phone (`+91 99999 99999`) and email (`info@multiflow.co.in`) with real ones
2. Have a lawyer finalize `legal.html`
3. Replace `localStorage` calls in `assets/app.js` with real API calls (Supabase recommended — fastest path to real auth + Postgres)
4. Connect actual channel providers (Meta WhatsApp Cloud API, an SMS/RCS aggregator, a voice provider, an email provider)
5. Point DNS for multiflow.co.in at your static host (Netlify/Vercel/GitHub Pages all work) once ready

## File structure
```
multiflow/
├── index.html, products.html, solutions.html, company.html,
│   blog.html, contact.html, legal.html      (marketing site)
├── signup.html, login.html                  (auth)
├── dashboard.html                           (customer app)
├── admin.html                               (reseller admin)
├── robots.txt, sitemap.xml                  (SEO)
└── assets/
    ├── style.css     (marketing site design system)
    ├── script.js     (marketing site interactivity)
    ├── app.css       (app shell: sidebar, chat, wizard, reports)
    └── app.js        (demo auth/data layer — swap for real API)
```
